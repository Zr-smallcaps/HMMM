<template>
  <div style="padding: 20px">
    <el-alert :closable="false" title="宇哥真的真的帅！" type="info" show-icon>
    </el-alert>
  </div>
</template>
<script>
export default {
  name: "",
  data() {
    return {};
  },
  components: {},
  computed: {},
  beforeMount() {},
  mounted() {},
  methods: {},
  watch: {},
};
</script>
<style lang="less" scoped></style>
