<template>
  <div class='container'>添加文章对话框</div>
</template>

<script>
export default {}
</script>

<style scoped lang='less'></style>
